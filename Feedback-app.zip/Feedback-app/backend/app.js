
const express = require('express');
const mongoose = require('mongoose');
const path = require('path');
const feedbackRoutes = require('./routes/feedback');
const useraccessRoutes = require('./routes/useraccess');

const app = express();

const connectionString = 'mongodb+srv://Abirami:k3AZCkcq06InWum0@cluster0.fqgpx.mongodb.net/Feedback?retryWrites=true&w=majority';
mongoose.connect(connectionString, {useNewUrlParser: true, useUnifiedTopology: true})
    .then(() => {
        console.log('DB Connection Success!');
    })
    .catch((err) => {
        console.log('DB Connection Failed!', err.message);
    });

// To parse req bodies
app.use(express.json());
app.use(express.urlencoded());

// By default, files are not accessible
// In order to access files, we are using express.static()
// The images targetting \images path will be forwarded to \backend\images
app.use('/images',express.static(path.join('./backend/images')));

// Headers
app.use((req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader("Access-Control-Allow-Credentials", "true");
    res.setHeader('Access-Control-Allow-Headers',  "Access-Control-Allow-Headers, Origin,Accept, X-Requested-With, Content-Type, Access-Control-Request-Method, Access-Control-Request-Headers, Authorization");
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH, DELETE, OPTIONS');
    next();
})

// Route to feedback
app.use('/api/feedback', feedbackRoutes);
// Route to useraccess
app.use('/api/useraccess', useraccessRoutes);

module.exports = app;
