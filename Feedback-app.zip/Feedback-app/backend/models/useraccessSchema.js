const mongoose = require('mongoose');
const uniqueValidator = require('mongoose-unique-validator');

const useraccessSchema = mongoose.Schema({
    // unique: true here is not a validator i.e it will not throw any error if email is not unique
    // There is 3rd party lib for unique validator - mongoose-unique-validator 
    // plugin - They allow for applying pre-packaged capabilities to extend their functionality
    email: {type: String, required: true, unique: true},
    password: {type: String, required: true}
})

useraccessSchema.plugin(uniqueValidator);

module.exports = mongoose.model('Useraccess', useraccessSchema);