const express = require('express');
const router = express.Router();
const multer = require('multer');
const Feedback = require('../models/feedbackSchema');
const checkAuth = require('../middleware/checkAuthentication');

let storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null,'./backend/images')
    },
    filename: (req, file, cb) => {
        const name = file.originalname.toLowerCase() + '_' + Date.now();
        const ext = file.mimetype 
        cb(null, name + '.png') 
    }
});

router.post('/save', checkAuth, multer({storage: storage}).single('Image'), (req, res, next) => {
    // req.protocol - Gives http or https
    // req.get('host') - Gives Full URL
    const url = req.protocol + "://" + req.get("host");
    const feedback = new Feedback({
        name: req.body.name,
        feedback: req.body.feedback,
        imagePath: url + '/images/' + req.file.filename
    });
    feedback.save()
    .then(response => {
        res.status(200).json({
            message: 'Feedback Saved Successfully',
            post: {
                id:response._id,
                ...response
            }
        });
    })
    .catch(err => {
        console.log(err);
    })
});

router.put('/update/:id', checkAuth, multer({storage: storage}).single('Image'), (req, res, next) => {
    console.log('req', req.body);
    const url = req.protocol + "://" + req.get("host");
    const feedback = new Feedback({
        _id:  req.params.id,
        name: req.body.name,
        feedback: req.body.feedback,
        imagePath: url + '/images/' + req.file.filename
    });
    Feedback.updateOne({_id: req.params.id}, feedback)
    .then(response => {
        res.status(200).json({
            message: 'Feedback Updated Successfully',
            post: {
                id:response._id,
                ...response
            }
        });
    })
    .catch((err) => {
        console.log(err)
    });
});

router.get('/get/all', checkAuth, (req, res, next) => {
    Feedback.find()
    .then((records) => {
        res.status(200).json({
            feedbacks: records
        });
    })
    .catch((err) => {
        console.log(err)
    });
});

router.get('/get/:id', checkAuth, (req,res,next) => {
    Feedback.findById(req.params.id)
    .then((record) => {
        console.log(record);
        res.status(200).json({
            feedback: {
                _id: record.id,
                name: record.name,
                feedback: record.feedback,
                imagePath: record.imagePath
            }
        });
    });
});

router.delete('/delete/:id', checkAuth, (req, res, next) => {
    Feedback.deleteOne({_id: req.params.id})
    .then(() => {
        res.status(200).json({
            message: 'Deleted Successfully'
        })
    })
    .catch(err => {
        console.log('Deletion failed')
    });
   
});

module.exports = router;