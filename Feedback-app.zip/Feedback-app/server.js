const http = require('http');
const app = require('./backend/app.js');
const port = process.env.port || 3000;
app.set(port);
const server = http.createServer(app);
server.listen(port);