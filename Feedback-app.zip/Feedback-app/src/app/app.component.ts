import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FeedbackService } from './service/feedback.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})

export class AppComponent implements OnInit {
  title = 'basic-node-app';

  constructor(private formBuilder: FormBuilder,
              private feedbackService: FeedbackService) {}

  ngOnInit(): void {
  }

}
