import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { UseraccessService } from '../service/useraccess.service';

@Injectable()

export class AuthGuard implements CanActivate{
    constructor(private useraccessService: UseraccessService,
                private router: Router) {}
    isUserAuthenticated!: boolean;
    private unsubscribe = new Subject();

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot)
                : boolean | UrlTree | Observable<boolean | UrlTree> | Promise<boolean | UrlTree> {

    const user = this.useraccessService.getToken();
    const isUserAuthenticated: boolean = user && user.token && user.expiresIn ? true : false;
    if (!isUserAuthenticated) {
        this.useraccessService.isAuthenticated
        .pipe(takeUntil(this.unsubscribe))
        .subscribe(isAuthenticated => {
            if (!isAuthenticated) {
                this.router.navigate(['/']);
            }
        });
    }
    return isUserAuthenticated;
    }
}
