interface FeedbackModel {
    _id: string | null;
    name: string;
    feedback: string;
    image: string;
}

interface ErrorModel {
    message: string;
}

interface SignupModel {
    email: string;
    password: string;
}

interface LoginResponseModel {
    message: string;
    token: string;
    expiresIn: number;
}

export {FeedbackModel, ErrorModel, SignupModel, LoginResponseModel};
