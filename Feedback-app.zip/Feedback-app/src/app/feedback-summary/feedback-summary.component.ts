import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { FeedbackModel } from '../feedback-form.model';
import { FeedbackService } from '../service/feedback.service';

@Component({
  selector: 'app-feedback-summary',
  templateUrl: './feedback-summary.component.html',
  styleUrls: ['./feedback-summary.component.scss']
})
export class FeedbackSummaryComponent implements OnInit {
  private unsubscribe = new Subject();
  feedbackList!: FeedbackModel[];

  constructor(private feedbackService: FeedbackService,
              private router: Router) { }

  ngOnInit(): void {
    this.viewAllFeedbacks();
  }

  viewAllFeedbacks(): void {
    this.feedbackService.viewAllFeedback()
    .pipe(takeUntil(this.unsubscribe))
    .subscribe((data) => {
      this.feedbackList = data.feedbacks;
      console.log('this.feedbackList', this.feedbackList);
    });
  }

  addFeedback(): void {
    this.router.navigate(['/create']);
  }

  editFeedback(feedbackId: string | null): void {
    this.router.navigate([`/edit/${feedbackId}`]);
  }

  deleteFeedback(feedbackId: string | null): void {
    if (feedbackId) {
      this.feedbackService.deleteFeedbackById(feedbackId)
      .pipe(takeUntil(this.unsubscribe))
      .subscribe(result => {
        console.log(result);
        this.viewAllFeedbacks();
      });
    }
  }

}
