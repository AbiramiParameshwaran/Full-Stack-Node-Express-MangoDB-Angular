import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Subject } from 'rxjs';
import { take, takeUntil, pluck } from 'rxjs/operators';
import { FeedbackService } from '../service/feedback.service';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { ErrorModel, FeedbackModel } from '../feedback-form.model';
import { isFeedbackModel, getPropertyValue } from '../utils/feedback.util';

@Component({
  selector: 'app-feedback',
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.scss']
})
export class FeedbackComponent implements OnInit, OnDestroy {

  private unsubscribe = new Subject();
  feedbackForm!: FormGroup;
  saveMessage = '';
  mode = '';
  feedbackId!: string | null;
  editFeedback!: FeedbackModel;
  imagePreview!: string | ArrayBuffer | null;

  constructor(private formBuilder: FormBuilder,
              private feedbackService: FeedbackService,
              private route: ActivatedRoute,
              private router: Router) {}

  ngOnInit(): void {
    this.route.paramMap
    .pipe(take(1))
    .subscribe((paramMap: ParamMap) => {
     if (paramMap.has('feedbackId')) {
      this.mode = 'Edit';
      this.feedbackId = paramMap.get('feedbackId') ? paramMap.get('feedbackId') : null;
      this.getFeedback();
     } else {
       this.mode = 'Create';
       this.feedbackId = null;
       this.initialiseForm();
     }
    });
  }

  initialiseForm(): void {
    this.feedbackForm = this.formBuilder.group({
      name: [this.checkForNull('name'), Validators.required],
      feedback: [this.checkForNull('feedback'), Validators.required],
      image: ['', Validators.required]
    });
    this.imagePreview = this.checkForNull('imagePath');
  }

  checkForNull(key: any): string | null {
    return this.editFeedback ? getPropertyValue(this.editFeedback, key) !== null
    && getPropertyValue(this.editFeedback, key) !== undefined ? getPropertyValue(this.editFeedback, key) : null : null;
  }

  getFeedback(): void {
    if (this.feedbackId) {
      this.feedbackService.getFeedbackById(this.feedbackId)
      .pipe(takeUntil(this.unsubscribe),
            pluck('feedback'))
      .subscribe((record) => {
        if (isFeedbackModel(record)) {
          this.editFeedback = record;
          this.initialiseForm();
        }
      });
    }
  }

  onFileUpload(event: any): void {
   const file: File | null = event?.target?.files ? event.target.files[0] : null;
   if (file) {
    this.feedbackForm.get('image')?.setValue(file);
    this.feedbackForm.get('image')?.updateValueAndValidity();
    console.log('this.feedbackForm', this.feedbackForm);
    const reader: FileReader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      this.imagePreview = reader.result;
   };
  }
  }

  onSubmit(): void {
    const feedbackRequest: FormData = new FormData();
    feedbackRequest.append('name', this.feedbackForm.value?.name);
    feedbackRequest.append('feedback', this.feedbackForm.value?.feedback);
    feedbackRequest.append('Image', this.feedbackForm.value?.image);

    this.feedbackService.saveFeedback(feedbackRequest, this.feedbackId, this.mode)
    .pipe(takeUntil(this.unsubscribe))
    .subscribe((data: any) =>  {
    this.saveMessage = data?.message;
    if (this.saveMessage === 'Feedback Saved Successfully' || this.saveMessage === 'Feedback Updated Successfully') {
      setTimeout(() => {
        this.feedbackForm.reset();
        this.saveMessage = '';
        this.router.navigate(['/']);
      }, 1500);
     }
    });
  }

  ngOnDestroy(): void {
   this.unsubscribe.next();
   this.unsubscribe.complete();
  }

}
