import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { UseraccessService } from '../service/useraccess.service';
import { isLoginSuccessResponseModel } from '../utils/feedback.util';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit, OnDestroy {
  loginForm!: FormGroup;
  saveMessage!: string;
  unSubscribe = new Subject();

  constructor(private formBuilder: FormBuilder,
              private useraccessService: UseraccessService,
              private router: Router) { }

  ngOnInit(): void {
    this.loginForm = this.formBuilder.group({
      email: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  onSubmit(): void {
    const loginRequest = {
      email: this.loginForm.value?.email,
      password: this.loginForm.value?.password
    };
    this.useraccessService.login(loginRequest)
    .pipe(takeUntil(this.unSubscribe))
    .subscribe( result => {
      if (isLoginSuccessResponseModel(result)) {
        this.useraccessService.setToken(result.token, result.expiresIn);
        this.router.navigate(['/feedback']);
        setTimeout(() => {
          this.useraccessService.clearToken();
        }, result.expiresIn * 1000);
      } else {
        this.saveMessage = result.message;
      }
    });
  }

  ngOnDestroy(): void {
    this.unSubscribe.next();
    this.unSubscribe.complete();
  }

}
