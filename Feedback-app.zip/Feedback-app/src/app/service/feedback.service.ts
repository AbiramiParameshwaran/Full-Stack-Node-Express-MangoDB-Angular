import { Injectable, OnDestroy } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FeedbackModel } from '../feedback-form.model';
import { Observable, Subject, of, forkJoin } from 'rxjs';
import { takeUntil, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class FeedbackService implements OnDestroy {
  private unsubscribe = new Subject();

  constructor(private http: HttpClient) { }

  saveFeedback(feedbackRequest: FormData,
               feedbackId: string | null, mode: string): Observable<{message: string, post: FeedbackModel} | {message: string}> {
    const errorMessage = mode === 'Create' ? {message: 'Save Feedback Failed'} : {message: 'Update Feedback Failed'};
    if (mode === 'Create') {
      const url = 'http://localhost:3000/api/feedback/save';
      return this.http.post<{message: string, post: FeedbackModel} | {message: string}>(url, feedbackRequest).pipe(
        takeUntil(this.unsubscribe),
        catchError((err) => of(errorMessage))
      );
    } else {
      const url = 'http://localhost:3000/api/feedback/update/' + feedbackId;
      return this.http.put<{message: string, post: FeedbackModel} | {message: string}>(url, feedbackRequest).pipe(
        takeUntil(this.unsubscribe),
        catchError((err) => of(errorMessage))
      );
    }
  }

  getFeedbackById(feedbackId: string): Observable<FeedbackModel | {message: string}> {
    const errorMessage = {message: 'Get Feedback By Id Failed'};
    const url = 'http://localhost:3000/api/feedback/get/' + feedbackId;
    return this.http.get<FeedbackModel>(url).pipe(
      takeUntil(this.unsubscribe),
      catchError((err) => of(errorMessage))
    );
  }

  deleteFeedbackById(feedbackId: string): Observable<{message: string}> {
    const errorMessage = {message: 'Get Feedback By Id Failed'};
    const url = 'http://localhost:3000/api/feedback/delete/' + feedbackId;
    return this.http.delete<{message: string}>(url).pipe(
      takeUntil(this.unsubscribe),
      catchError((err) => of(errorMessage))
    );
  }

  viewAllFeedback(): Observable<any> {
    const errorMessage = {message: 'View Feedback Fetch Failed'};
    const url = 'http://localhost:3000/api/feedback/get/all';
    return this.http.get<any>(url).pipe(
      takeUntil(this.unsubscribe),
      catchError((err) => of(errorMessage))
    );
  }

  ngOnDestroy(): void {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }
}
