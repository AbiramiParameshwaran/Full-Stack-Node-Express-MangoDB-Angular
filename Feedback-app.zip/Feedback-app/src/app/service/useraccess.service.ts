import { HttpClient } from '@angular/common/http';
import { Injectable, OnDestroy } from '@angular/core';
import { BehaviorSubject, Observable, of, Subject } from 'rxjs';
import { catchError, takeUntil } from 'rxjs/operators';
import { SignupModel } from '../feedback-form.model';

@Injectable({
  providedIn: 'root'
})
export class UseraccessService implements OnDestroy{
  private unsubscribe = new Subject();
  public isAuthenticated = new BehaviorSubject(false);
  constructor(private http: HttpClient) { }

  signup(signupRequest: SignupModel): Observable<{message: string, result: SignupModel} | {message: string}> {
    const errorMessage = {message: 'Signup Error'};
    const url = 'http://localhost:3000/api/useraccess/signup';
    return this.http.post<{message: string, result: SignupModel} | {message: string}>(url, signupRequest)
      .pipe(
        takeUntil(this.unsubscribe),
        catchError((err) => of(err))
      );
  }

  login(loginRequest: SignupModel): Observable<{message: string} | {message: string, token: string}> {
    const errorMessage = {message: 'Login Failed'};
    const url = 'http://localhost:3000/api/useraccess/login';
    return this.http.post<{message: string} | {message: string, token: string, expiresIn: number}>(url, loginRequest)
    .pipe(
      takeUntil(this.unsubscribe),
      catchError((err) => of(errorMessage))
    );
  }

  setToken(token: string | null, expiresIn: number | null): void {
    if (token && expiresIn) {
      localStorage.setItem('token', token);
      localStorage.setItem('expiresIn', expiresIn.toString());
      this.isAuthenticated.next(true);
    }
  }

  getToken(): {token: string | null, expiresIn: string | null} {
    const token = localStorage.getItem('token');
    const expiresIn = localStorage.getItem('expiresIn');
    return {token, expiresIn};
  }

  clearToken(): void {
    localStorage.clear();
    this.isAuthenticated.next(false);
  }

  ngOnDestroy(): void {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }
}

