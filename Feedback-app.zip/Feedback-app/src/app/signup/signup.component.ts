import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { SignupModel } from '../feedback-form.model';
import { UseraccessService } from '../service/useraccess.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss']
})
export class SignupComponent implements OnInit {

  signUpForm!: FormGroup;
  private unSubscribe = new Subject();
  saveMessage!: string;
  constructor(private formBuilder: FormBuilder,
              private useraccessService: UseraccessService) { }

  ngOnInit(): void {
    this.signUpForm = this.formBuilder.group({
      email: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  onSubmit(): void {
    const signupRequest: SignupModel = {
      email: this.signUpForm.value?.email,
      password: this.signUpForm.value?.email
    };
    this.useraccessService.signup(signupRequest)
    .pipe(takeUntil(this.unSubscribe))
    .subscribe( response => {
        this.saveMessage = response.message;
    });
  }

}
