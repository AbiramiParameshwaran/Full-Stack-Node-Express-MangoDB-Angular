import { FeedbackModel, LoginResponseModel } from '../feedback-form.model';

function isFeedbackModel(record: any): record is FeedbackModel {
    return record && '_id' in record;
}

function getPropertyValue<T, K extends keyof T>(object: T, property: K): T[K] {
    return  object[property];
}

function isLoginSuccessResponseModel(record: any): record is LoginResponseModel {
    return record && 'token' in record;
}

export {
    isFeedbackModel, getPropertyValue, isLoginSuccessResponseModel
};
